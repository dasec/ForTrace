"""
Twisted.web2.client: Client Implementation
"""
