# -*- test-case-name: twisted.web2.test -*-
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.


"""

Twisted Web2: a better Twisted Web Server.

"""

from twisted.web2._version import version
__version__ = version.short()
