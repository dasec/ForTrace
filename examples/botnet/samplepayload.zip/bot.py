print "this is sample bot"
raw_input("press enter to exit:")
